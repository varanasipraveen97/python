s = input("Enter a string: ")
if s == s[::-1]:
 print("Palindrome")
else:
    print("Not a palindrome")
#output:-
#Enter a string: madam
#Palindrome

